> https://reboot.studio/blog/folder-structures-to-organize-react-project/

copy design: https://gomobile.website/demos/index.html
https://material-ui.com/ru/components/drawers/