import React from 'react'

import { ContextGlobal } from '../src/contexts/ContextGlobal'
import { AppState } from './components/app/AppState'

function App() {

    return (
        <ContextGlobal>
            <AppState />
        </ContextGlobal>
    );
}

export default App;
