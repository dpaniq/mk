import React from 'react'
import {useEffect, useState} from 'react'

import Cookie from 'js-cookie';

import { axiosPost } from '../utils/axios'
import Contexts from './_contexts'

/* Functions */
async function checkSession(setSessionId, setStateApp) {
    const sessionId = Cookie.get('sessionId')
    // const response = await axiosPost('test', {})
    const response = await axiosPost('check_session', {sessionId})

    if (response.success) {
        setSessionId(Cookie.get('sessionId'))
        setStateApp(3)
    } else {
        setStateApp(2)
    }
}

export function ContextGlobal({ children }) {


    const APP_STATE = {
        0: 'App is initializing',
        1: 'App is loading',
        2: 'App stopped (bad sessionId)',
        3: 'App process'
    };

    /* App */
    const [stateApp, setStateApp] = useState(0)
    const [sessionId, setSessionId] = useState(false)

    /* Teams */
    const [myTeam, setMyTeam] = useState([])
    // const [teams, setTeams] = useState([])

    console.log(`APP_STATE :: ${stateApp} [${APP_STATE[stateApp]}]`)

    useEffect(() => {
        if (stateApp == 0) {
            setStateApp(1)
        }
        checkSession(setSessionId, setStateApp)
    }, []);

    const values = {
        sessionId, 
        stateApp, setStateApp
    }

    return (
        <Contexts.Global.Provider value={values}>
            {children}
        </Contexts.Global.Provider>
    )
}
