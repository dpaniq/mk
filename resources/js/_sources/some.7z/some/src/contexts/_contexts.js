import { createContext } from 'react'

/**
 * Has some nesting from top to bottom!
 */
const Contexts = {
    /**
     *  Global context contains ...
     */ 
    Global: createContext(null)
}

export default Contexts