const axios = require('axios')

export async function axiosPost(url, data = {}) {
    
    const currentUrl = (url == 'test')
        ? 'https://webhook.site/58f27412-4115-431c-9443-c6a982156f2d'
        : `${process.env.API_HOSTNAME}/${process.env.API_CLIENT}/${url}`
    
    const config = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'multipart/form-data',
        },
    }

    return await axios.post(currentUrl, data, config)
        .then(function (response) {
            return (response.data.success && !response.data?.error) 
                ? {success: true, data: response?.data?.data}
                : {success: false, error: response?.data?.error}
        })
        .catch(function (error) {
            console.log(error);
        })
}