
import React from 'react'
import { Container } from '../components/container/Container'
import { ContentAchivements } from '../components/content/ContentAchivements'
export const Achivements = () => {
    return (
        <Container>
            <ContentAchivements />
        </Container>
    )
}