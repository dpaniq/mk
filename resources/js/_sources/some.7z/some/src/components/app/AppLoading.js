import React from 'react'

import '../../scss/components/loader.scss'

export const AppLoading = () => (
    <div id="loader">
        <div className="loader__text">Loading...</div>
    </div>
)

