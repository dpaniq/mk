import React from 'react'

import '../../scss/components/app/app_stop.scss'
import '../../scss/main.scss';

import ShieldCrossSVG from '../../assets/images/svg/shieldCross.svg'
import { Container } from '../container/Container';

export const AppStop = () => (
    <Container>
        <div className="appStop">
            <div className="appStop__main">
                <img src={ShieldCrossSVG} width="150px"/>
                <p>Неудачная авторизация</p>
            </div>
        </div>
    </Container>
)

