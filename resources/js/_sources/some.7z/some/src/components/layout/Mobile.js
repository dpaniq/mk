import React from 'react'
import { Container } from '../container/Container'

export const Mobile = () => {
    return (
        <>
            <Container />
            
        </>
    )
}