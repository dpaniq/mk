import React from 'react'
export const ContentTeam = () => {
    return (
        <>
            <div className="teamHeader">
                <div className="teamHeader__title">
                    Команда
                </div>
            </div>
            <div className="teamContent">
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
                <div className="teamContent__row">
                    <a data-fancybox="gallery" data-caption="Георгий" href="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__imgWrap">
                        <img src="https://html.nkdev.info/godlike/assets/images/image-1-600x600.jpg" className="teamContentRow__img" alt="" />
                    </a>
                    <span className="teamContentRow__name">
                        Георгий
                    </span>
                </div>
            </div>
        </>
    )
}