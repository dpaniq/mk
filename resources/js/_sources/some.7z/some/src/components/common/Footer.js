import React from 'react'
import { Menu } from '../menu/Menu'
export const Footer = () => {
    return (
        <div className="footer">
            <div className="footer__menu">
                {/* <Menu /> */}
            </div>
        </div>
    )
}
