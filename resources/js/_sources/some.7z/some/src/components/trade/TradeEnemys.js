import React, { useState, useEffect, useContext, useCallback, useRef } from 'react'
import Swal from 'sweetalert2'

import { axiosPost } from '../../utils/axios'
import Contexts from '../../contexts/_contexts'

import '../../scss/components/team/enemy_teams.scss'

import SwordSVG from '../../assets/images/svg/sword.svg'
import ScalesSVG from '../../assets/images/svg/scales.svg'

export const TradeEnemys = ({ getBalance, maxBalance, teams }) => {

    const { sessionId } = useContext(Contexts.Global)

    const [balance, setBalance] = useState(0)
    const [toTeamId, setToTeamId] = useState(null)
    const [detail, setDetail] = useState('')

    const errorBalance = () => {
        Swal.fire({
            icon: 'error',
            title: 'Произошла ошибка',
            text: 'Количество золото должно быть больше нуля',
            showConfirmButton: true,
        })
    }

    const errorDetail = () => {
        Swal.fire({
            icon: 'error',
            title: 'Произошла ошибка',
            text: 'Укажите детали для команды',
            showConfirmButton: true,
        })
    }

    async function sendToTeam() {
        if (balance <= 0) { errorBalance(); return; }
        if (detail.trim() == '') { errorDetail(); return; }

        if (balance && toTeamId) {
            const response = await axiosPost(`send_balance`, { sessionId, toTeamId, balance, detail })
            if (response.success && !response?.error) {
                Swal.fire({
                    icon: 'success',
                    title: 'Золото отправлено',
                    showConfirmButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        getBalance()
                    }
                })
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Произошла ошибка',
                    showConfirmButton: true,
                }).then((result) => {
                    if (result.isConfirmed) {
                        getBalance()
                    }
                })
            }
            setBalance(0)
            setToTeamId(0)
            setDetail('')
        }
    }

    const balanceChange = (event) => setBalance(Number(event.target.value))
    const balanceIncrementX1 = () => setBalance(balance + 1)
    const balanceDecrementX1 = () => (balance - 1 < 0) ? setBalance(0) : setBalance(balance - 1)

    const handleToTeamId = (teamId) => {
        if (teamId == toTeamId) {
            setToTeamId(0)
            return;
        }
        setToTeamId(teamId)
    }

    const getTeamImage = (teamId) => {
        if (teamId == toTeamId) return ScalesSVG
        return teams[teamId]['IMAGE']
            ? teams[teamId]['IMAGE']
            : SwordSVG
    }

    return (
        <>
            <div className="enemy-teams">
                <br />
                <h3>Выберите команду для торговли:</h3>
                {Object.keys(teams).map((key, index) => (
                    <div className={key == toTeamId ? 'enemy active' : 'enemy'} key={index} onClick={() => handleToTeamId(key)}>
                        {/* <img className="enemy__img" src={key == toTeamId ? ScalesSVG : SwordSVG} /> */}
                        <img className="enemy__img" src={getTeamImage(key)} />
                        <div className="enemy__title">
                            {teams[key]['TITLE']}
                        </div>

                    </div>
                ))}
                <br />

                {toTeamId > 0 && <>
                    {/* <h3>Отправить команде:</h3> */}
                    <div className="calculator__hr"></div>
                    <h4>Укажите количество золотых:</h4>
                    <div className="enemy__input">
                        <button className="countBttn" onClick={balanceDecrementX1}>
                            <span>&#8722;</span>
                        </button>
                        <input type="number"
                            min="0"
                            max={maxBalance}
                            pattern="[1-9]"
                            title="Balance"
                            placeholder={0}
                            value={balance > 0 ? balance : ''}
                            onChange={balanceChange}
                            required
                        />
                        <button className="countBttn" onClick={balanceIncrementX1}>
                            <span>&#x2b;</span>
                        </button>
                    </div>
                    <br />
                    <div className="enemy__textarea">
                        <textarea name="" id="" placeholder="Детали" onChange={(event) => setDetail(event.target.value)} value={detail}></textarea>
                    </div>
                    <div className="enemy__input">
                        <button className="countSubmit countSubmit__team" onClick={sendToTeam} disabled={balance == 0 ? true : false}>Отправить</button>
                    </div>
                </>
                }
            </div>
        </>
    )
}